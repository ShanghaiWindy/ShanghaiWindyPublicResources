# Embedded Spline Sample

This sample shows how a Spline can be embedded in a component - an alternative approach to attaching a `SplineContainer` to a game object.
