# Spline Extrude Sample

This sample demonstrates how Splines can be extruded using the Extrude component.

Press "Play" to generate and update a Spline mesh.
