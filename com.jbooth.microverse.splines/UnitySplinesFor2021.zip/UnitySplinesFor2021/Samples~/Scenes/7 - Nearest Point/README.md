# Nearest Point Sample

This sample showcases the use of `SplineUtility.GetNearestPoint` function. See `ShowNearestPoint.cs` script on how, given an arbitrary point, the closest point on the Spline can be found.

Play the sample scene to see a visualization of the function's results.
