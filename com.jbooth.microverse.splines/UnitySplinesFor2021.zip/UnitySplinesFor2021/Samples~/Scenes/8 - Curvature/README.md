# Curvature Sample

This sample showcases a number of `SplineUtility` functions for Spline curvature evaluation. See `DisplayCurvatureOnSplineEditor.cs` script on how a Spline curvature visualization tool can be written.
