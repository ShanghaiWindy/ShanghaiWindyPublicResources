using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Unity.Splines.Examples
{
    public class Car : MonoBehaviour {}
}
