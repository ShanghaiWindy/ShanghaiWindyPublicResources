using UnityEngine.UIElements;

namespace UnityEditor.Splines
{
    sealed class Separator : VisualElement
    {
        public Separator()
        {
            AddToClassList("unity-separator");
        }
    }
}
