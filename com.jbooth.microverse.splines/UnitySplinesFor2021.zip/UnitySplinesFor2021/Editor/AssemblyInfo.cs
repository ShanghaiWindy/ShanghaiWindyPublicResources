using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Splines.Editor.Tests")]
[assembly: InternalsVisibleTo("Unity.Splines.Editor.Debug")]