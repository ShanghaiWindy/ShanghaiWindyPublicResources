# Splines upgrade guide

This is a new package release. In future package versions, this page will display a list of the actions you need to take to upgrade your project to that version.