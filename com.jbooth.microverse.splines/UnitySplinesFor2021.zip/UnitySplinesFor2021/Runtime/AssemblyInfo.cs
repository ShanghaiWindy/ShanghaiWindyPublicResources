using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Splines.Editor")]
[assembly: InternalsVisibleTo("Unity.Splines.Tests")]
[assembly: InternalsVisibleTo("Unity.Splines.Editor.Tests")]
